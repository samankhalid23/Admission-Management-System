#pragma once
#include <iostream>

using namespace std;

// THIS IS KIND OF OUR DATABASE 

string firstName[20]; string lastName[20];
string rollno[20] = {"99801","999802","999803","999804", "999805", "999806", "999807", "999808", "999809" , "999810" ,"999811"  ,"999812"  "999813" ,"999814" ,"999815" ,"999816" ,"999817" ,"999818" ,"999819", "999820"};
string hobby[20];
//int siblings;
string fathername[20], mothername[20], CNIC[20];
string occupation[20];
string gender[20], status[20];
string DOB[20], cellno[20], cellno1[20], bloodgroup[20];
string age[20], income[20];
string m_cellno[20], m_cellno1[20], m_occupation[20], m_income[20], m_email[20];
string present_address[20], permanent_address[20], email[20], mark[20];
string religion[20], nationality[20], province[20], domicile[20];
string s_name[20], s_occupation[20];



// DATA OF SCHOOL FORM

string s_lastInstitute[20];
int s_class[20];
int s_lastClass[20];
float s_preMarks[20];                 // Obtained marks in previous Class
float s_preTMarks[20];                // Total Marks in previous Class
float s_percentage[20];       